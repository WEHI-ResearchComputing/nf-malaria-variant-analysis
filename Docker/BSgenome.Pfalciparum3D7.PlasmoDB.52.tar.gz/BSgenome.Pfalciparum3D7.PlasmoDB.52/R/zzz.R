###
###

.pkgname <- "BSgenome.Pfalciparum3D7.PlasmoDB.52"

.seqnames <- NULL

.circ_seqs <- "Pf3D7_API_v3"

.mseqnames <- NULL

.onLoad <- function(libname, pkgname)
{
    if (pkgname != .pkgname)
        stop("package name (", pkgname, ") is not ",
             "the expected name (", .pkgname, ")")
    extdata_dirpath <- system.file("extdata", package=pkgname,
                                   lib.loc=libname, mustWork=TRUE)

    ## Make and export BSgenome object.
    bsgenome <- BSgenome(
        organism="Plasmodium falciparum 3D7",
        common_name="P. falciparum",
        genome="PlasmoDB-52_Pfalciparum3D7_Genome.fasta",
        provider="GeneDB via PlasmoDB",
        release_date="2021-05-18",
        source_url="http://plasmodb.org/common/downloads/release-52/Pfalciparum3D7/fasta/data/",
        seqnames=.seqnames,
        circ_seqs=.circ_seqs,
        mseqnames=.mseqnames,
        seqs_pkgname=pkgname,
        seqs_dirpath=extdata_dirpath
    )

    ns <- asNamespace(pkgname)

    objname <- pkgname
    assign(objname, bsgenome, envir=ns)
    namespaceExport(ns, objname)

    old_objname <- "Pfalciparum3D7"
    assign(old_objname, bsgenome, envir=ns)
    namespaceExport(ns, old_objname)
}

