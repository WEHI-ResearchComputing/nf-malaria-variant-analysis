###
###

.pkgname <- "BSgenome.PfalciparumNF54iGP"

.seqnames <- NULL

.circ_seqs <- c("Pf3D7_API_v3", "Pf3D7_MIT_v3")

.mseqnames <- NULL

.onLoad <- function(libname, pkgname)
{
    if (pkgname != .pkgname)
        stop("package name (", pkgname, ") is not ",
             "the expected name (", .pkgname, ")")
    extdata_dirpath <- system.file("extdata", package=pkgname,
                                   lib.loc=libname, mustWork=TRUE)

    ## Make and export BSgenome object.
    bsgenome <- BSgenome(
        organism="Plasmodium falciparum 3D7 NF54-iGP",
        common_name="P. falciparum",
        genome="Pfalciparum_sup",
        provider="PlasmoDB",
        release_date="2023-03-28",
        source_url="-- information not available --",
        seqnames=.seqnames,
        circ_seqs=.circ_seqs,
        mseqnames=.mseqnames,
        seqs_pkgname=pkgname,
        seqs_dirpath=extdata_dirpath
    )

    ns <- asNamespace(pkgname)

    objname <- pkgname
    assign(objname, bsgenome, envir=ns)
    namespaceExport(ns, objname)

    old_objname <- "PvivaxP01"
    assign(old_objname, bsgenome, envir=ns)
    namespaceExport(ns, old_objname)
}

