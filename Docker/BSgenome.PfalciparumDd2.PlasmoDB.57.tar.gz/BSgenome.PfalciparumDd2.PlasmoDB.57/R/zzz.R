###
###

.pkgname <- "BSgenome.PfalciparumDd2.PlasmoDB.57"

.seqnames <- NULL

.circ_seqs <- "PfDd2_API"

.mseqnames <- NULL

.onLoad <- function(libname, pkgname)
{
    if (pkgname != .pkgname)
        stop("package name (", pkgname, ") is not ",
             "the expected name (", .pkgname, ")")
    extdata_dirpath <- system.file("extdata", package=pkgname,
                                   lib.loc=libname, mustWork=TRUE)

    ## Make and export BSgenome object.
    bsgenome <- BSgenome(
        organism="Plasmodium falciparum Dd2",
        common_name="P. falciparum",
        genome="PlasmoDB-52_Pfalciparum3D7_Genome.fasta",
        provider="GeneDB via PlasmoDB",
        release_date="2022-06-22",
        source_url="http://plasmodb.org/common/downloads/release-57/PfalciparumDd2/fasta/data/",
        seqnames=.seqnames,
        circ_seqs=.circ_seqs,
        mseqnames=.mseqnames,
        seqs_pkgname=pkgname,
        seqs_dirpath=extdata_dirpath
    )

    ns <- asNamespace(pkgname)

    objname <- pkgname
    assign(objname, bsgenome, envir=ns)
    namespaceExport(ns, objname)

    old_objname <- "PfalciparumDd2"
    assign(old_objname, bsgenome, envir=ns)
    namespaceExport(ns, old_objname)
}

